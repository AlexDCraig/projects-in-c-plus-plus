/* Program Filename: Creature.h
 * Author: Alex Hoffer
 * Date: 10/31/2015
 * Description: Skeleton for the Creature class, the class that is the 
 * basis for all of the other classes.
 */

#ifndef CREATURE_H
#define CREATURE_H

#include <string>
using std::string;

class Creature // abstract base class, cannot be instantiated.
{
protected:
	int attack;
	int defense;
	int armor;
	int strengthPoints;
	string name;

public:
	Creature();
	virtual int calculateAttack() = 0; // each subclass will calculate their attack on their own. This function needs to set the Attack.
	virtual int calculateDefense() = 0; // pure virtual function, not defined in base class. So inherited classes MUST define this function.
	virtual bool getHasPlayed() = 0;
	void attackCreature(Creature*);
	void setName(string); // derived classes will tell this function in their default constructor what the name of their class is
	void setAttack(int);
	void setDefense(int);
	void setArmor(int);
	void setStrengthPoints(int);
	virtual void incrementTimesKilled() = 0;
	virtual void incrementTimesBeenKilled() = 0;
	virtual int getTimesKilled() = 0;
	virtual int getTimesBeenKilled() = 0;
	void printRecord();
	string getName();
	int getAttack();
	int getDefense();
	int getArmor();
	int getStrengthPoints();
};

#endif
